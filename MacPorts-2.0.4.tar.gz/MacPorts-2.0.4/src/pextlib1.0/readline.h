/*
 * readline.h
 * $Id: readline.h 19376 2006-09-02 03:19:06Z yeled@macports.org $
 *
 */

int ReadlineCmd(ClientData, Tcl_Interp *, int, Tcl_Obj *CONST objv[]);
int RLHistoryCmd(ClientData, Tcl_Interp *, int, Tcl_Obj *CONST objv[]);
