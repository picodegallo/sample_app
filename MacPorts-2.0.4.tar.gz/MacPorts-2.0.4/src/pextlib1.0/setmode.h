/*
 * $Id: setmode.h 73999 2010-12-01 22:50:58Z jmr@macports.org $
 */

mode_t getmode(const void *bbox, mode_t omode);
void * setmode(const char *p);
